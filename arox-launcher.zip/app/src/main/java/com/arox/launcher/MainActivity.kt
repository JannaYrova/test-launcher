package com.arox.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

// Интерфейс целиком в assets/index.html (WebView). Kotlin отвечает только за запуск игры и ссылки.
class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0A0A0C")
        window.navigationBarColor = Color.parseColor("#0A0A0C")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0A0A0C"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    inner class Bridge {
        // Запуск Minecraft (com.mojang.minecraftpe). Вернёт false, если игра не установлена.
        @JavascriptInterface
        fun launchMinecraft(): Boolean {
            val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe") ?: return false
            runOnUiThread { startActivity(intent) }
            return true
        }

        // TODO: подставить реальную ссылку на Telegram-канал «Arox Client»
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }
    }

    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack ? window.onBack() : false)") { r ->
            if (r != "true") finish()
        }
    }
}
